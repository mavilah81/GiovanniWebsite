GIOVANNIAPP — NUOVO SITO IMMERSIVO (prototipo completo)
- index.html: landing page con sezioni Experience, funzioni, modalità, chat demo, filosofia e CTA
- styles.css: layout responsive desktop/mobile, glow, animazioni e componenti
- script.js: menu mobile e reveal animation
Aprire index.html oppure avviare: python3 -m http.server 8001
NOTA: questa versione usa un simbolo astratto al posto di un ritratto per non inserire un Giovanni non canonico. I testi descrivono l’esperienza; non certificano disponibilità delle funzioni nell’APK.
