const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');io.unobserve(e.target)}}),{threshold:.13});document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
// Gentle parallax, only on pointer devices
if(matchMedia('(pointer:fine)').matches){const p=document.querySelector('.portrait');window.addEventListener('mousemove',e=>{const x=(e.clientX/innerWidth-.5)*7,y=(e.clientY/innerHeight-.5)*-7;p.style.transform=`translate(${x}px,${y}px)`},{passive:true});window.addEventListener('mouseleave',()=>p.style.transform='');}
